<!doctype html>
<html lang="ar" dir="rtl">

<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <meta name="description" content="المسبح الأولومبي الجامعة الإسلامية">
    <meta name="keywords" content="مسبح, اولومبي, الجامعة الاسلامية ">
    <meta name="author" content="الجامعة الاسلامية">

    <link rel="stylesheet" href="<?php echo e(asset('assets/web/css/bootstrap.rtl.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/web/css/owl.theme.default.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/web/css/owl.carousel.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/web/fonts/flaticon.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/web/css/boxicons.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/web/css/animate.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/web/css/meanmenu.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/web/css/magnific-popup.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/web/css/nice-select.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/web/css/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/web/css/responsive.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/web/css/theme-dark.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/web/css/rtl.css')); ?>">
    <title><?php echo e($settings?->website_name ?? 'ضع الاسم من لوحة التحكم'); ?></title>
    <link rel="icon" type="image/png" href="assets/img/favicon.png">

    <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::styles(); ?>

    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <?php if (isset($component)) { $__componentOriginal8344cca362e924d63cb0780eb5ae3ae6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8344cca362e924d63cb0780eb5ae3ae6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'livewire-alert::components.scripts','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('livewire-alert::scripts'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8344cca362e924d63cb0780eb5ae3ae6)): ?>
<?php $attributes = $__attributesOriginal8344cca362e924d63cb0780eb5ae3ae6; ?>
<?php unset($__attributesOriginal8344cca362e924d63cb0780eb5ae3ae6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8344cca362e924d63cb0780eb5ae3ae6)): ?>
<?php $component = $__componentOriginal8344cca362e924d63cb0780eb5ae3ae6; ?>
<?php unset($__componentOriginal8344cca362e924d63cb0780eb5ae3ae6); ?>
<?php endif; ?>
</head>

<body>

    <div class="preloader">
        <div class="d-table">
            <div class="d-table-cell">
                <div class="spinner">
                    <div class="circle1"></div>
                    <div class="circle2"></div>
                    <div class="circle3"></div>
                </div>
            </div>
        </div>
    </div>

    <?php echo $__env->make('partials.web.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('partials.web.top-bar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('content'); ?>
    <?php echo $__env->make('partials.web.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <script data-cfasync="false" src="../../cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script>

    <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::scripts(); ?>

    <script src=" <?php echo e(asset('assets/web/js/jquery.min.js')); ?> "></script>
    <script src="<?php echo e(asset('assets/web/js/bootstrap.bundle.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/web/js/owl.carousel.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/web/js/wow.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/web/js/meanmenu.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/web/js/jquery.magnific-popup.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/web/js/jquery.nice-select.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/web/js/jquery.ajaxchimp.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/web/js/form-validator.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/web/js/contact-form-script.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/web/js/custom.js')); ?>"></script>



    <?php echo $__env->yieldPushContent('contact-us-script-js'); ?>




</body>

</html>
<?php /**PATH F:\Laravel\OlympicSwimmingPool\resources\views/layouts/web/landing-page.blade.php ENDPATH**/ ?>