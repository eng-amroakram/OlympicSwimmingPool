<label class="form-label"><strong><?php echo e($label); ?></strong></label>
<div class="input-group">
    <span class="input-group-text">
        <i class="fas fa-pen"></i>
    </span>

    <input type="file" wire:model.live="<?php echo e($name); ?>" class="form-control"
        placeholder="ارفق <?php echo e($label); ?>" />

</div>
<div class="form-helper text-danger <?php echo e($name); ?>-<?php echo e($model); ?>-validation reset-validation">
</div>
<?php /**PATH F:\Laravel\OlympicSwimmingPool\resources\views/components/file-input.blade.php ENDPATH**/ ?>