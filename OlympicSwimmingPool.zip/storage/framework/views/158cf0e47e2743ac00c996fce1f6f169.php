<?php $__env->startSection('content'); ?>
    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('web.contact-us');

$__html = app('livewire')->mount($__name, $__params, 'lw-295853200-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>


    <div class="home-area">
        <div class="container-fluid m-0 p-0">

            <div class="home-slider owl-carousel owl-theme">
                <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="slider-item" style="background-image: url(<?php echo e($slider->photo_table); ?>)">
                        <div class="slider-content banner-content">
                            <h3><?php echo e($slider->sub_title); ?></h3>
                            <h1><?php echo e($slider->title); ?></h1>
                            <p><?php echo e($slider->description); ?></p>

                            <div class="slider-btn">
                                <a target="_blank" href="<?php echo e($slider->link); ?>" class="default-btn default-bg-white">إكتشف
                                    أكثر</a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>

    <div class="about-area darkbg pt-100">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-6">
                    <div class="about-content">
                        <div class="section-title">
                            <h2 class="yallowbg"><?php echo e($about_us?->title); ?></h2>

                            <ul class="features">

                                <?php $__currentLoopData = $about_us?->features_relation ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li>
                                        <?php echo e($feature->name); ?>

                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>

                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="about-img">
                        <div class="about-single">
                            <img src="<?php echo e(asset('assets/web/img/about/1.jpg')); ?>" alt="About Images">

                            <div class="about-play">
                                <a href="<?php echo e($about_us?->video_link); ?>" class="play-btn">
                                    <i class="bx bx-play"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <section class="project-area pt-100 pb-70">
        <div class="container-fluid">
            <div class="container-max">
                <div class="section-title text-center">
                    
                    <h2 class="margin-auto">خدماتنا</h2>
                    
                </div>


                <div class="row pt-45">

                    <?php $__currentLoopData = $our_services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $our_service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-lg-3 col-sm-6">
                            <div class="project-card">
                                <div class="project-card-img">
                                    <a href="projects.html">
                                        <img src="<?php echo e($our_service->photo_table); ?>" alt="Project Images">
                                    </a>
                                    <div class="project-content">

                                        <a href="projects.html">
                                            <h3><?php echo e($our_service->title); ?></h3>
                                        </a>
                                        <a target="_blank" href="<?php echo e(route('web.our_service', $our_service->id)); ?>"
                                            class="view-more-btn">
                                            <i class="flaticon-diagonal-arrow"></i>
                                            تعرف اكثر
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
            </div>
        </div>
    </section>

    <div class="location">
        <div class="container">
            <div class="row darkbg align-items-center">
                <div class="col-lg-5">
                    <div class="info-title">
                        <h2 class="yallowbg"><?php echo e($location?->title); ?></h2>
                        <ul class="info">
                            <li>
                                <i class="flaticon-email"></i>
                                <span>العنوان</span>
                                <p><?php echo e($location?->address); ?></p>

                            </li>
                            <li>
                                <i class="flaticon-email"></i>

                                <span>البريد الالكتروني
                                </span>
                                <p><?php echo e($location?->email); ?></p>
                            </li>
                            <li>
                                <i class="flaticon-phone-call"></i>
                                <span> الهاتف</span>
                                <p><?php echo e($location?->phone); ?></p>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-7">
                    <img src="<?php echo e(asset('assets/web/img/home2.jpg')); ?>" alt="map Images">
                </div>
            </div>
        </div>
    </div>

    <div class="gallery-area pt-100 pb-70">
        <div class="container">

            <div class="section-title text-center">
                <span>مرئيات</span>
                <h2 class="margin-auto color-title-blue">صور ومرئيات</h2>
            </div>

            <div class="brand-slider-two container-max owl-carousel owl-theme owl-rtl owl-loaded owl-drag">

                <div class="owl-stage-outer pt-45">

                    <div class="owl-stage"
                        style="transition: all 0.25s ease 0s; width: 4244px; transform: translate3d(2122px, 0px, 0px);">

                        <?php $__currentLoopData = $gallery; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="owl-item cloned gallery-view" style="width: 235.2px; margin-left: 30px;">

                                <div class="single-gallery">
                                    <img src="<?php echo e($photo->photo_table); ?>" alt="Gallery Images">
                                    <a href="<?php echo e($photo->photo_table); ?>" class="single-icon">
                                        <i class="bx bx-show-alt"></i>
                                    </a>
                                </div>

                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                    </div>
                </div>
            </div>
        </div>
    </div>

    <section class="blog-area pt-100 pb-70">
        <div class="container">
            <div class="section-title text-center">
                
                <h2 class="margin-auto">الاخبار والانشطة</h2>
                
                </p>
            </div>
            <div class="row pt-45">

                <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-4 col-md-6">
                        <div class="blog-card">
                            <a href="blog-details.html">
                                <img src="<?php echo e($blog->photo_table); ?>" alt="Blog Images">
                            </a>
                            <div class="blog-content">
                                <ul>
                                    <li>
                                        <i class="bx bx-time-five"></i>
                                        <?php echo e($blog->created_at); ?>

                                    </li>
                                </ul>
                                <a href="blog-details.html">
                                    <h3><?php echo e($blog->title); ?></h3>
                                </a>
                                <a target="_blank" href="<?php echo e(route('web.blog-details', $blog->id)); ?>" class="more-blog">
                                    <i class="flaticon-diagonal-arrow"></i>
                                    اقرا المزيد
                                </a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>





            </div>
        </div>
    </section>

    <div class="brand-area-two pb-100">
        <div class="container">
            <div class="brand-slider-two container-max owl-carousel owl-theme owl-rtl owl-loaded owl-drag">

                <div class="owl-stage-outer">
                    <div class="owl-stage"
                        style="transition: all 0.25s ease 0s; width: 4244px; transform: translate3d(2122px, 0px, 0px);">

                        <?php $__currentLoopData = $partners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $partner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="owl-item cloned" style="width: 235.2px; margin-left: 30px;">
                                <div class="brand-item-two">
                                    <a href="#">
                                        <img src="<?php echo e($partner->photo_table); ?>" class="brand-item-logo1"
                                            alt="Brand Images">
                                        <img src="<?php echo e($partner->photo_table); ?>" class="brand-item-logo2"
                                            alt="Brand Images">
                                    </a>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>
                </div>
                <div class="owl-nav disabled">
                    <button type="button" role="presentation" class="owl-prev">
                        <span aria-label="Previous">‹</span></button><button type="button" role="presentation"
                        class="owl-next"><span aria-label="Next">›</span></button>
                </div>
                <div class="owl-dots disabled"></div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.web.landing-page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Laravel\OlympicSwimmingPool\resources\views/pages/web/landing-page.blade.php ENDPATH**/ ?>