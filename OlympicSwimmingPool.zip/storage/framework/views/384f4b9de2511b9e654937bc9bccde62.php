<div class="container-fluid">
    <div class="p-4 mb-4">


        <!-- Page Header-->
        <div class="row mb-4" wire:ignore>

            <!-- Page Title  -->
            <h2 style="font-weight: bold;">حولنا</h2>
            <!-- Page Title  -->

            <!-- Breadcrumb -->
            <nav data-mdb-navbar-init class="d-flex navbar navbar-expand-lg bg-body-tertiary">
                <div class="container-fluid">

                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb" style="font-weight: bold;">
                            <li class="breadcrumb-item"><a href="#">لوحة التحكم</a></li>
                            <li class="breadcrumb-item"><a href="#">قسم حولنا</a></li>
                            <li class="breadcrumb-item active"><a href="#">حولنا</a>
                            </li>
                        </ol>
                    </nav>

                    <div class="d-flex align-items-center pe-3">
                        <!-- Notifications -->
                        <div class="dropdown">
                            <a data-mdb-toggle="dropdown" class="link-secondary me-3 dropdown-toggle" href="#"
                                id="navbarDropdownMenuLink" role="button" aria-expanded="false">
                                <i class="fas fa-gear"></i>
                            </a>
                            <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdownMenuLink">
                                <li>
                                    <a class="dropdown-item" data-mdb-toggle="modal"
                                        data-mdb-target="#create-new-about-us-modal" href="#create-new-about-us-modal">
                                        <i class="far fa-square-plus me-2"></i>
                                        <span>إضافة بيانات حولنا</span>
                                    </a>
                                </li>
                                

                            </ul>
                        </div>

                    </div>
                </div>
            </nav>
            <!-- Breadcrumb -->
        </div>
        <!-- Page Header-->

        <!-- Data Tables -->
        <div class="row" wire:ignore>
            <div class="row p-2 mb-3">

                

                <div class="col-md-3">
                    <select class="select" multiple wire:model.live="search_status">
                        <option value="active">نشط</option>
                        <option value="inactive">غير نشط</option>
                    </select>
                </div>

            </div>
        </div>

        <div class="table-responsive-md">
            <table class="table table-bordered text-center">
                <thead>
                    <tr>
                        <th class="th-sm"><strong>ID</strong></th>
                        <th data-mdb-sort="true" class="th-sm"><strong>الاسم</strong></th>
                        <th data-mdb-sort="true" class="th-sm"><strong>المميزات</strong></th>
                        <th data-mdb-sort="true" class="th-sm"><strong>رابط اليوتيوب</strong></th>
                        <th data-mdb-sort="false" class="th-sm"><strong>الحالة</strong></th>
                        <th data-mdb-sort="false" class="th-sm"><strong>التحكم</strong></th>
                    </tr>
                </thead>
                <tbody>
                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $about_uses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $about_us): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($about_us->id); ?></td>
                            <td><?php echo e($about_us->title); ?></td>
                            <td>

                                <div class="dropdown">
                                    <button type="button" class="btn btn-primary dropdown-toggle"
                                        data-mdb-toggle="dropdown" data-mdb-ripple-init aria-expanded="false">
                                        المميزات
                                    </button>
                                    <ul class="dropdown-menu">
                                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $about_us->features_relation; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><a class="dropdown-item" href="#"><?php echo e($feature->name); ?></a></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                    </ul>
                                </div>


                            </td>
                            <td> <a target="_blank" href="<?php echo e($about_us->video_link); ?>"><strong>Youtube</strong></a>
                            </td>
                            <td>
                                <div class="switch">
                                    <label>
                                        نشط
                                        <input wire:click="changeStatus(<?php echo e($about_us->id); ?>)" type="checkbox"
                                            <?php echo e($about_us->status == 'active' ? 'checked' : ''); ?>>
                                        <span class="lever"></span>
                                        غير نشط
                                    </label>
                                </div>
                            </td>

                            <td>
                                <div class="d-flex justify-content-center">
                                    <a type="button" class="text-danger fa-lg me-2 ms-2"
                                        wire:click='delete(<?php echo e($about_us->id); ?>)' title="Delete">
                                        <i class="fas fa-trash-can"></i>
                                    </a>
                                    <a type="button" class="text-dark fa-lg me-2 ms-2 set-button-update"
                                        data-mdb-toggle="modal" data-mdb-target="#create-new-about-us-modal"
                                        href="#create-new-about-us-modal" title="EditAboutUs"
                                        wire:click="edit(<?php echo e($about_us->id); ?>)">
                                        <i class="far fa-pen-to-square"></i>
                                    </a>
                                </div>
                            </td>

                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->

                </tbody>
            </table>
        </div>

        <!-- Table Pagination -->
        <div class="d-flex justify-content-between">

            <nav aria-label="...">
                <ul class="pagination pagination-circle">
                    <?php echo e($about_uses->withQueryString()->onEachSide(0)->links()); ?>

                </ul>
            </nav>

            <div class="col-md-1" wire:ignore>
                <select class="select" wire:model.live="pagination">
                    <option value="5">5</option>
                    <option value="10" selected>10</option>
                    <option value="25">25</option>
                    <option value="50">50</option>
                    <option value="100">100</option>
                </select>
            </div>

        </div>
        <!-- Table Pagination -->

    </div>

    <div class="modal top fade" id="create-new-about-us-modal" tabindex="-1" data-mdb-backdrop="static"
        aria-labelledby="Creator" aria-hidden="true" wire:ignore>
        <div class="modal-dialog cascading-modal" style="margin-top: 4%">
            <div class="modal-content">
                <div class="modal-c-tabs">

                    <!-- Tabs navs -->
                    <ul class="nav md-tabs nav-tabs" id="create-new-about-us" role="tablist"
                        style="background-color: #303030;">
                        <li class="nav-item" role="presentation">
                            <a data-mdb-tab-init class="nav-link active" id="create-new-about-us-tab-1"
                                href="#create-new-about-us-tabs-1" role="tab"
                                aria-controls="create-new-about-us-tabs-1" aria-selected="true">
                                <i class="fas fa-circle-info me-1"></i>
                                <strong>
                                    بيانات حولنا
                                </strong>
                            </a>
                        </li>
                    </ul>

                    <div class="tab-content" id="ex1-content">

                        <div class="mask mask-color" wire:loading
                            style="z-index: 1; background-color: #303030; opacity: 50%;">
                            <div
                                class="position-absolute w-100 h-100 d-flex flex-column align-items-center justify-content-center">
                                <div class="spinner-border text-primary" role="status">
                                    <span class="sr-only text-primary">Loading...</span>
                                </div>
                                <h4 class="text-white">جاري التحميل يرجى الانتظار ...</h4>
                            </div>
                        </div>


                        <div class="tab-pane fade show active" id="create-new-about-us-tabs-1" role="tabpanel"
                            aria-labelledby="create-new-about-us-tab-1">

                            <div class="modal-body">

                                <div class="row mb-3">
                                    <div class="col-md-12">
                                        <?php if (isset($component)) { $__componentOriginal18c21970322f9e5c938bc954620c12bb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal18c21970322f9e5c938bc954620c12bb = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.text-input','data' => ['label' => 'العنوان','name' => 'title','model' => 'aboutus']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('text-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'العنوان','name' => 'title','model' => 'aboutus']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal18c21970322f9e5c938bc954620c12bb)): ?>
<?php $attributes = $__attributesOriginal18c21970322f9e5c938bc954620c12bb; ?>
<?php unset($__attributesOriginal18c21970322f9e5c938bc954620c12bb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal18c21970322f9e5c938bc954620c12bb)): ?>
<?php $component = $__componentOriginal18c21970322f9e5c938bc954620c12bb; ?>
<?php unset($__componentOriginal18c21970322f9e5c938bc954620c12bb); ?>
<?php endif; ?>
                                    </div>
                                </div>

                                <div class="row mb-3">
                                    <div class="col-md-12">
                                        <?php if (isset($component)) { $__componentOriginal74895d84926454708d0c75fd1f52bcb6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal74895d84926454708d0c75fd1f52bcb6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.link-input','data' => ['label' => 'رابط اليوتيوب','name' => 'video_link','model' => 'aboutus']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('link-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'رابط اليوتيوب','name' => 'video_link','model' => 'aboutus']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal74895d84926454708d0c75fd1f52bcb6)): ?>
<?php $attributes = $__attributesOriginal74895d84926454708d0c75fd1f52bcb6; ?>
<?php unset($__attributesOriginal74895d84926454708d0c75fd1f52bcb6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal74895d84926454708d0c75fd1f52bcb6)): ?>
<?php $component = $__componentOriginal74895d84926454708d0c75fd1f52bcb6; ?>
<?php unset($__componentOriginal74895d84926454708d0c75fd1f52bcb6); ?>
<?php endif; ?>
                                    </div>
                                </div>

                                <div class="row">
                                    <?php if (isset($component)) { $__componentOriginal8e4831396dc81f32aab4c3fd4cae0ddd = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8e4831396dc81f32aab4c3fd4cae0ddd = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.mult-select-input','data' => ['modelid' => '#create-new-about-us-modal','name' => 'features','model' => 'aboutus','id' => 'about-us-features','label' => 'المميزات','options' => features(true)]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('mult-select-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['modelid' => '#create-new-about-us-modal','name' => 'features','model' => 'aboutus','id' => 'about-us-features','label' => 'المميزات','options' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(features(true))]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8e4831396dc81f32aab4c3fd4cae0ddd)): ?>
<?php $attributes = $__attributesOriginal8e4831396dc81f32aab4c3fd4cae0ddd; ?>
<?php unset($__attributesOriginal8e4831396dc81f32aab4c3fd4cae0ddd); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e4831396dc81f32aab4c3fd4cae0ddd)): ?>
<?php $component = $__componentOriginal8e4831396dc81f32aab4c3fd4cae0ddd; ?>
<?php unset($__componentOriginal8e4831396dc81f32aab4c3fd4cae0ddd); ?>
<?php endif; ?>
                                </div>


                            </div>

                            <div class="modal-footer">

                                <button type="button" class="btn bg-blue-color close-modal-button"
                                    data-mdb-dismiss="modal" x-on:click="$wire.resetting()">
                                    إغلاق
                                </button>

                                
                                <button type="button" class="btn text-white blue-color create-button"
                                    wire:click='addAboutUs()'>حفظ</button>

                                <button type="button" class="btn text-white blue-color update-button"
                                    wire:click='updateAboutUs()'>تحديث</button>
                                

                            </div>
                        </div>

                    </div>
                    <!-- Tabs content -->
                </div>
            </div>
        </div>
    </div>
</div>


<?php $__env->startPush('create-new-about-us-script'); ?>
    <script>
        $(document).ready(function() {

            $(".update-button").hide();

            Livewire.on("process-has-been-done", function() {
                $(".reset-validation").text("");
                $("#create-new-about-us-modal").modal('hide');
                $(".create-button").show();
                $(".update-button").hide();
            });

            Livewire.on("create-new-feature-errors", function(errors) {
                $(".reset-validation").text("");
                for (let key in errors[0]) {
                    if (errors[0].hasOwnProperty(key)) {
                        $("." + key + "-about-us-validation").text(errors[0][key]);
                    }
                }
            });

            Livewire.on("set-about-us-features", function(data) {
                const singleSelect = document.querySelector("#about-us-features");
                const singleSelectInstance = mdb.Select.getInstance(singleSelect);
                singleSelectInstance.setValue(data[0]['features']);
                $(".create-button").hide();
                $(".update-button").show();
            });

            $(".set-button-update").on('click', function() {
                $(".create-button").hide();
                $(".update-button").show();
            });

            $(".close-modal-button").on("click", function() {
                const singleSelect = document.querySelector("#about-us-features");
                const singleSelectInstance = mdb.Select.getInstance(singleSelect);
                singleSelectInstance.setValue([]);
                $(".create-button").show();
                $(".update-button").hide();
            });

        });
    </script>
<?php $__env->stopPush(); ?>
<?php /**PATH F:\Laravel\OlympicSwimmingPool\resources\views/livewire/admin/about-us.blade.php ENDPATH**/ ?>