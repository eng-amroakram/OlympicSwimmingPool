<footer class="footer-area">
    <div class="footer-top">

        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-4 col-sm-6 col-md-6">
                    <div class="footer-logo">
                        <a href="<?php echo e(route('web.landing-page')); ?>">
                            <img src="<?php echo e($settings?->photo_table); ?>" alt="Images">
                        </a>
                    </div>
                </div>
                <div class="col-lg-4 col-sm-6 col-md-6">
                    <div class="footer-top-card">
                        <i class="flaticon-calendar"></i>
                        <span>أيام العمل:</span>
                        <h3>من <?php echo e(__($settings?->day_from)); ?> الي <?php echo e(__($settings?->day_to)); ?></h3>
                    </div>
                </div>
                <div class="col-lg-4 col-sm-6 col-md-6">

                    <div class="footer-top-card">
                        <i class="flaticon-alarm-clock"></i>
                        <span>أوقات العمل:</span>
                        <h3>
                            <?php echo e($settings?->time_to); ?>

                            -
                            <?php echo e($settings?->time_from); ?>

                        </h3>
                    </div>
                </div>

            </div>
        </div>
    </div>

    <div class="footer-bottom">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 col-md-6">

                    <div class="bottom-text right">
                        <p>
                            جميع الحقوق محفوظة للجامعة الاسلامية بالمدينة المنورة
                        </p>
                    </div>

                </div>
                <div class="col-lg-6 col-md-6">

                    <div class="bottom-text">
                        <p>
                            تطوير شركة
                            <a href="#">حلول التقنية</a>
                        </p>
                    </div>

                </div>
            </div>
        </div>
    </div>
</footer>
<?php /**PATH F:\Laravel\OlympicSwimmingPool\resources\views/partials/web/footer.blade.php ENDPATH**/ ?>