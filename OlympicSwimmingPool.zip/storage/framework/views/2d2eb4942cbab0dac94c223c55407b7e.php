<header class="top-header">
    <div class="container">
        <div class="row">
            <div class="col-lg-8">
                <div class="header-right">
                    <div class="header-right-card">
                        <ul>

                            <li>
                                <div class="head-icon">
                                    <i class="flaticon-phone-call"></i>
                                </div>
                                <a href="tel:+(704)279-1249"><?php echo e($location?->phone); ?> (966)+</a>
                            </li>
                            <li>
                                <div class="head-icon">
                                    <i class="flaticon-email"></i>
                                </div>
                                <a href="../../cdn-cgi/l/email-protection.html#03396a6d656c43736a796a2d606c6e"><span
                                        class="__cf_email__"
                                        data-cfemail="c5acaba3aa85b5acbfaceba6aaa8"><?php echo e($location?->email); ?></span></a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="col-lg-4">
                <div class="top-social-link">
                    <ul>
                        <?php if($location?->facebook): ?>
                            <li>
                                <a class="color-blue" href="<?php echo e($location?->facebook); ?>" target="_blank">
                                    <i class="bx bxl-facebook"></i>
                                </a>
                            </li>
                        <?php endif; ?>

                        <?php if($location?->twitter): ?>
                            <li>
                                <a class="active" href="<?php echo e($location?->twitter); ?>" target="_blank">
                                    <i class="bx bxl-twitter"></i>
                                </a>
                            </li>
                        <?php endif; ?>

                        <?php if($location?->instagram): ?>
                            <li>
                                <a class="color-pink" href="<?php echo e($location?->instagram); ?>" target="_blank">
                                    <i class="bx bxl-instagram"></i>
                                </a>
                            </li>
                        <?php endif; ?>

                        <?php if($location?->tiktok): ?>
                            <li>
                                <a class="active" href="<?php echo e($location?->tiktok); ?>" target="_blank">
                                    <i class="bx bxl-tiktok"></i>
                                </a>
                            </li>
                        <?php endif; ?>

                        <?php if($location?->snap_chat): ?>
                            <li>
                                <a class="color-blue" href="<?php echo e($location?->snap_chat); ?>" target="_blank">
                                    <i class="bx bxl-snapchat"></i>
                                </a>
                            </li>
                        <?php endif; ?>

                        

                    </ul>
                </div>
            </div>
        </div>
    </div>
</header>
<?php /**PATH F:\Laravel\OlympicSwimmingPool\resources\views/partials/web/header.blade.php ENDPATH**/ ?>