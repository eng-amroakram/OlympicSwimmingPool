<?php $__env->startSection('content'); ?>
    <div class="inner-banner inner-bg2">
        <div class="container">
            <div class="inner-title text-center">
                <h3>عنوان الصفحة يكتب هنا</h3>

                <ul>
                    <li>
                        <a href="index.html">الرئيسية</a>
                    </li>
                    <li>
                        <i class="bx bx-chevron-right"></i>
                    </li>
                    <li>رابط</li>
                </ul>

            </div>
        </div>
    </div>

    <div class="service-dtls-area pt-100 pb-70">
        <div class="container">
            <div class="row">
                <div class="col-lg-4">
                    <div class="service-left-side">
                        <div class="service-catagory">
                            <h3>جميع الخدمات</h3>
                            <ul>
                                <li class="active">
                                    <i class="flaticon-send"></i>
                                    نص تجريبي للخدمة
                                </li>
                                <li>
                                    <i class="flaticon-send"></i>
                                    عنوان الخدمة يكتب هنا
                                </li>
                                <li>
                                    <i class="flaticon-send"></i>
                                    عنوان الخدمة الاخري
                                </li>
                                <li>
                                    <i class="flaticon-send"></i>
                                    نص تجريبي عنوان يكتب هنا
                                </li>
                                <li>
                                    <i class="flaticon-send"></i>
                                    عنوان الخدمة نص تجريبي
                                </li>
                                <li>
                                    <i class="flaticon-send"></i>
                                    عنوان الخدمة يكتب هنا
                                </li>
                            </ul>
                        </div>
                        <div class="service-list-side">
                            <ul>
                                <li>
                                    <div class="service-list-icon">
                                        <i class="flaticon-phone-call"></i>
                                    </div>
                                    <span>تواصل معنا</span>
                                    <h3>+(966) 579-1249</h3>
                                </li>
                                <li>
                                    <div class="service-list-icon">
                                        <i class="flaticon-email"></i>
                                    </div>
                                    <span>البريد الالكتروني</span>
                                    <h3><a href="../../cdn-cgi/l/email-protection.html" class="__cf_email__"
                                            data-cfemail="761f18101936061f0c1f5815191b">Info@website.com</a></h3>
                                </li>
                                <li>
                                    <div class="service-list-icon">
                                        <i class="flaticon-alarm-clock"></i>
                                    </div>
                                    <span>الاحد:</span>
                                    <h3>09:00AM - 07:00PM</h3>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-lg-8">
                    <div class="service-dtls-content">

                        <div class="service-img">
                            <img src="<?php echo e(asset('assets/web/img/service/1.jpg')); ?> " alt="Images">
                        </div>

                        <div class="section-title">
                            <h2 class="color-title-blue">عنوان الخدمة يكتب هنا</h2>
                            <p>
                                نص تجريبي لتفاصيل الخدمة يكتب هنا نبذة مختصرة للتفاصيل نص تجريبي لتفاصيل الخدمة يكتب هنا
                                عنوان وتفاصيل الخدمة نص تجريبي لنبذة مختصرة
                            </p>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.web.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Laravel\OlympicSwimmingPool\resources\views/pages/web/service.blade.php ENDPATH**/ ?>