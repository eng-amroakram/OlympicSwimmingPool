        <!-- Navbar -->
        <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
            <!-- Container wrapper -->
            <div class="container">
                <!-- Toggle button -->
                <button data-mdb-collapse-init class="navbar-toggler" type="button"
                    data-mdb-target="#navbarRightAlignExample" aria-controls="navbarRightAlignExample"
                    aria-expanded="false" aria-label="Toggle navigation">
                    <i class="fas fa-bars"></i>
                </button>

                <!-- Collapsible wrapper -->
                <div class="collapse navbar-collapse" id="navbarRightAlignExample">


                    <!-- Navbar brand -->
                    <a class="navbar-brand mt-2 mt-lg-0" href="#">
                        <img src="<?php echo e(asset('assets/admin/images/logo-white.png')); ?>" height="28"
                            alt="Munagasatcom Brand" loading="lazy" />
                    </a>
                    <!-- Navbar brand -->

                    <!-- Left links -->
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('admin.index')); ?>">الرئيسية</a>
                        </li>
                        
                    </ul>
                    <!-- Left links -->
                </div>
                <!-- Collapsible wrapper -->

                <!-- Right elements -->
                <div class="d-flex align-items-center">
                    <ul class="navbar-nav d-flex flex-row">
                        <!-- Notifications -->
                        

                        <!-- Avatar -->
                        <div class="dropdown">
                            <a data-mdb-dropdown-init class="dropdown-toggle d-flex align-items-center hidden-arrow"
                                href="#" data-mdb-toggle="dropdown" id="navbarDropdownMenuAvatar" role="button"
                                aria-expanded="false">
                                <img src="https://mdbcdn.b-cdn.net/img/new/avatars/2.webp" class="rounded-circle"
                                    height="25" alt="Black and White Portrait of a Man" loading="lazy" />
                            </a>
                            <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdownMenuAvatar">
                                <li>
                                    <a class="dropdown-item" href="<?php echo e(route('admin.logout')); ?>">تسجيل الخروج</a>
                                </li>
                            </ul>
                        </div>
                </div>
                <!-- Right elements -->
            </div>




            </div>
            <!-- Container wrapper -->
        </nav>

        <!-- Navbar -->
<?php /**PATH F:\Laravel\OlympicSwimmingPool\resources\views/partials/admin/navbar.blade.php ENDPATH**/ ?>