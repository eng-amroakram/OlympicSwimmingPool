<label class="form-label"><strong><?php echo e($label); ?></strong></label>
<div class="input-group">
    <span class="input-group-text">
        <i class="fas fa-pen"></i>
    </span>

    <input type="text" wire:model.defer="<?php echo e($name); ?>" maxlength="30" class="form-control"
        placeholder="ادخل <?php echo e($label); ?>" />

</div>
<div class="form-helper text-danger <?php echo e($name); ?>-<?php echo e($model); ?>-validation reset-validation">
</div>
<?php /**PATH F:\Laravel\OlympicSwimmingPool\resources\views/components/text-input.blade.php ENDPATH**/ ?>