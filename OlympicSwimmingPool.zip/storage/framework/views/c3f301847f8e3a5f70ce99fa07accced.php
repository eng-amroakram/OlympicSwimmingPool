<label class="form-label select-label mb-1"><strong><?php echo e($label); ?></strong></label>
<div class="input-group">
    <textarea wire:model.defer="<?php echo e($name); ?>" maxlength="500" class="form-control" style="height: 100px;">
</textarea>
</div>

<div class="form-helper text-danger <?php echo e($name); ?>-<?php echo e($model); ?>-validation reset-validation">
</div>
<?php /**PATH F:\Laravel\OlympicSwimmingPool\resources\views/components/textarea.blade.php ENDPATH**/ ?>