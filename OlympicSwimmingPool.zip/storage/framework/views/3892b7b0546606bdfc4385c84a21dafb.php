<?php $__env->startSection('content'); ?>
    <div class="inner-banner inner-bg2">
        <div class="container">
            <div class="inner-title text-center">
                

            </div>
        </div>
    </div>

    <div class="service-dtls-area pt-100 pb-70">
        <div class="container">
            <div class="row">
                <div class="col-lg-4">
                    <div class="service-left-side">
                        <div class="service-catagory">
                            <h3>جميع الخدمات</h3>
                            <ul>
                                <?php $__currentLoopData = $our_services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $our_service_selected): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="<?php echo e($our_service_selected->id == $our_service->id ? 'active' : ''); ?>">
                                        <a style="text-decoration: none; color: inherit;"
                                            href="<?php echo e(route('web.our_service', $our_service_selected->id)); ?>">
                                            <i class="flaticon-send"></i>
                                            <?php echo e($our_service_selected->title); ?>

                                        </a>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                        <div class="service-list-side">
                            <ul>
                                <li>
                                    <div class="service-list-icon">
                                        <i class="flaticon-phone-call"></i>
                                    </div>
                                    <span>تواصل معنا</span>
                                    <h3><?php echo e($location->phone); ?> (966)+</h3>
                                </li>
                                <li>
                                    <div class="service-list-icon">
                                        <i class="flaticon-email"></i>
                                    </div>
                                    <span>البريد الالكتروني</span>
                                    <h3><a href="../../cdn-cgi/l/email-protection.html" class="__cf_email__"
                                            data-cfemail="761f18101936061f0c1f5815191b"><?php echo e($location->email); ?></a></h3>
                                </li>
                                <li>
                                    <div class="service-list-icon">
                                        <i class="flaticon-alarm-clock"></i>
                                    </div>
                                    <span>من <?php echo e(__($settings?->day_from)); ?> الي <?php echo e(__($settings?->day_to)); ?></span>
                                    <h3>
                                        <?php echo e($settings?->time_to); ?>

                                        -
                                        <?php echo e($settings?->time_from); ?>

                                    </h3>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>

                <div class="col-lg-8">
                    <div class="service-dtls-content">

                        <div class="service-img">
                            <img src="<?php echo e($our_service->photo_table); ?> " alt="Images">
                        </div>

                        <div class="section-title">
                            <h2 class="color-title-blue"><?php echo e($our_service->title); ?></h2>
                            <p>
                                <?php echo $our_service->description; ?>

                            </p>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.web.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Laravel\OlympicSwimmingPool\resources\views/pages/web/our_service.blade.php ENDPATH**/ ?>