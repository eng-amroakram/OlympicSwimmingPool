<label class="form-label"><strong><?php echo e($label); ?></strong></label>
<select class="select" id="<?php echo e($id); ?>" wire:model.live="<?php echo e($name); ?>" data-mdb-filter="true"
    data-mdb-container="<?php echo e($modelid); ?>">
    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($key); ?>"><?php echo e($value); ?></option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
</select>
<div class="form-helper text-danger <?php echo e($name); ?>-<?php echo e($model); ?>-validation reset-validation">
</div>
<?php /**PATH F:\Laravel\OlympicSwimmingPool\resources\views/components/select-input.blade.php ENDPATH**/ ?>